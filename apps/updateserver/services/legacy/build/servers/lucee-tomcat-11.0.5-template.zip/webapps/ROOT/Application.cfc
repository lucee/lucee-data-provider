﻿component {

	this.Name = "Lucee";
}